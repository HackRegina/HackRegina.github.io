const clientId = process.env.CLIENT_ID
const clientSecret = process.env.CLIENT_SECRET
const axios = require('axios')

exports.handler = (event, context, callback) => {

  const body = JSON.parse(event.body)

  axios.post('https://github.com/login/oauth/access_token', {
    client_id: clientId,
    client_secret: clientSecret,
    code: body.code,
  }, {
    headers: {
      'X-OAuth-Scopes': 'public_repo',
      'X-Accepted-OAuth-Scopes': 'public_repo'
    }
  }).then(({data}) => {
    callback(null, {
      statusCode: '200',
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
    })
  }).catch(({response}) => {
    callback(null, {
      statusCode: '500',
      body: JSON.stringify(response.data),
      headers: {
        'Content-Type': 'application/json',
      },
    })
  })
}
